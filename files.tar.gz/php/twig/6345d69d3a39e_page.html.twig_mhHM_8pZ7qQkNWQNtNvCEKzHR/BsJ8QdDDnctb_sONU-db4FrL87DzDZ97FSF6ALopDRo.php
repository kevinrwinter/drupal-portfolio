<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/breeze/templates/page.html.twig */
class __TwigTemplate_488d1c5ca7b33138091544ee8d9921cdc5cc58f732196cd788919f9d68f941c4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 48
        echo "<div class=\"layout-container\">
\t<div class=\"container\">
  \t<header role=\"banner\" class=\"section-header\">
  \t\t<div class=\"row\">
\t\t  \t<div class=\"logo col-md-6 col-sm-6 col-xs-12\">
\t\t    \t";
        // line 53
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header", [], "any", false, false, true, 53), 53, $this->source), "html", null, true);
        echo "
\t\t\t\t</div>
\t\t\t\t<div class=\"header-right col-md-6 col-sm-6 col-xs-12\">
\t\t\t\t\t";
        // line 56
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_right", [], "any", false, false, true, 56), 56, $this->source), "html", null, true);
        echo "
\t\t\t\t</div>
\t\t\t</div>
  \t</header>
  \t<div class=\"navigation-wrapper\">
\t\t\t<div class=\"navigation\">
\t\t\t\t";
        // line 62
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "navigation", [], "any", false, false, true, 62), 62, $this->source), "html", null, true);
        echo "
\t\t\t</div>
\t\t</div>

\t\t";
        // line 66
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 66)) {
            // line 67
            echo "\t\t\t";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 67), 67, $this->source), "html", null, true);
            echo "
\t\t";
        }
        // line 69
        echo "
\t\t";
        // line 70
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 70)) {
            // line 71
            echo "  \t\t";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 71), 71, $this->source), "html", null, true);
            echo "
  \t";
        }
        // line 73
        echo "
\t\t";
        // line 74
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 74)) {
            // line 75
            echo "  \t\t";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 75), 75, $this->source), "html", null, true);
            echo "
  \t";
        }
        // line 77
        echo "
\t\t";
        // line 78
        $context["sidebarClass"] = "col-md-12";
        // line 79
        echo "\t\t\t";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 79)) {
            // line 80
            echo "\t\t\t\t";
            $context["sidebarClass"] = "col-md-8 col-sm-8";
            // line 81
            echo "\t\t\t";
        }
        // line 82
        echo "\t\t\t";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 82)) {
            // line 83
            echo "\t\t\t\t";
            $context["sidebarClass"] = "col-md-8 col-sm-8";
            // line 84
            echo "\t\t\t";
        }
        // line 85
        echo "\t\t\t";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 85)) {
            // line 86
            echo "\t\t\t\t";
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 86)) {
                // line 87
                echo "\t\t\t  \t";
                $context["sidebarClass"] = "col-md-4 col-sm-4";
                // line 88
                echo "\t\t\t\t";
            }
            // line 89
            echo "\t\t\t";
        }
        // line 90
        echo "
  \t<main role=\"main\">
\t  \t<div class=\"row\">

\t\t\t\t<a id=\"main-content\" tabindex=\"-1\"></a>";
        // line 95
        echo "
\t    \t<div class=\"layout-content ";
        // line 96
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["sidebarClass"] ?? null), 96, $this->source), "html", null, true);
        echo "\">
\t      \t";
        // line 97
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 97), 97, $this->source), "html", null, true);
        echo "
\t    \t</div>";
        // line 99
        echo "
\t    \t";
        // line 100
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 100)) {
            // line 101
            echo "\t      \t<aside class=\"layout-sidebar-first col-md-4 col-sm-4\" role=\"complementary\">
\t        \t";
            // line 102
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 102), 102, $this->source), "html", null, true);
            echo "
\t      \t</aside>
\t    \t";
        }
        // line 105
        echo "
\t    \t";
        // line 106
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 106)) {
            // line 107
            echo "\t      \t<aside class=\"layout-sidebar-second col-md-4 col-sm-4\" role=\"complementary\">
\t        \t";
            // line 108
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 108), 108, $this->source), "html", null, true);
            echo "
\t      \t</aside>
\t    \t";
        }
        // line 111
        echo "\t\t\t</div>
  \t</main>
\t\t<div class=\"content-bottom row\">
\t\t\t<div class=\"content-bottom-1 col-md-4 col-sm-4\">";
        // line 114
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom1", [], "any", false, false, true, 114), 114, $this->source), "html", null, true);
        echo "</div>
\t\t\t<div class=\"content-bottom-2 col-md-4 col-sm-4\">";
        // line 115
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom2", [], "any", false, false, true, 115), 115, $this->source), "html", null, true);
        echo "</div>
\t\t\t<div class=\"content-bottom-3 col-md-4 col-sm-4\">";
        // line 116
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom3", [], "any", false, false, true, 116), 116, $this->source), "html", null, true);
        echo "</div>
\t\t</div>

\t\t<footer role=\"contentinfo\" class=\"footer\">
\t\t\t<div class=\"section-footer\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t";
        // line 122
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer1", [], "any", false, false, true, 122)) {
            // line 123
            echo "\t\t    \t\t<div class=\"footer_one col-md-4 col-sm-4\">
\t\t      \t\t";
            // line 124
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer1", [], "any", false, false, true, 124), 124, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 127
        echo "\t\t      ";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer2", [], "any", false, false, true, 127)) {
            // line 128
            echo "\t\t\t\t\t\t<div class=\"footer_second col-md-4 col-sm-4\">
\t\t\t\t\t\t\t";
            // line 129
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer2", [], "any", false, false, true, 129), 129, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 132
        echo "\t\t\t\t\t";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer3", [], "any", false, false, true, 132)) {
            // line 133
            echo "\t\t\t\t\t\t<div class=\"footer_third col-md-4 col-sm-4\">
\t\t\t\t\t\t\t";
            // line 134
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer3", [], "any", false, false, true, 134), 134, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 137
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</footer>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "themes/contrib/breeze/templates/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  238 => 137,  232 => 134,  229 => 133,  226 => 132,  220 => 129,  217 => 128,  214 => 127,  208 => 124,  205 => 123,  203 => 122,  194 => 116,  190 => 115,  186 => 114,  181 => 111,  175 => 108,  172 => 107,  170 => 106,  167 => 105,  161 => 102,  158 => 101,  156 => 100,  153 => 99,  149 => 97,  145 => 96,  142 => 95,  136 => 90,  133 => 89,  130 => 88,  127 => 87,  124 => 86,  121 => 85,  118 => 84,  115 => 83,  112 => 82,  109 => 81,  106 => 80,  103 => 79,  101 => 78,  98 => 77,  92 => 75,  90 => 74,  87 => 73,  81 => 71,  79 => 70,  76 => 69,  70 => 67,  68 => 66,  61 => 62,  52 => 56,  46 => 53,  39 => 48,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/breeze/templates/page.html.twig", "/app/web/themes/contrib/breeze/templates/page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 66, "set" => 78);
        static $filters = array("escape" => 53);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
